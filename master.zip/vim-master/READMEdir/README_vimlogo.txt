The Python project that creates `vimlogo.svg` can be found at
`https://github.com/ShayHill/vimlogo`.  The Vim license applies.

`vimlogo.svg` is an effort to remove errors and inadvertant inconsistencies
from the original vim logo while maintaing the original design. `vimlogo.svg`
is based on the `vimlogo.svg` file (previously?) found at
`https://www.vim.org/logos.php`

As of 2024 Jan 30, `vimlogo.svg` is a separate project from `vimlogo.cdr`,
`vimlogo.eps`, `vimlogo.gif`, `vimlogo.pdf`, and `vimlogo.xpm`, all of which
are slightly different from each other.
